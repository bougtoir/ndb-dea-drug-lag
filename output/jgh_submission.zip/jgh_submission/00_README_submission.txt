Journal of Gastroenterology and Hepatology - submission package
===============================================================================

00_cover_letter.docx        Cover letter (word and reference counts, all-authors
                            approval; author details to be completed locally)
01_manuscript_main.docx     Main manuscript for submission: title page (article type,
                            short title, authors/affiliations/ORCID, corresponding
                            author, word counts, conflict of interest, financial
                            support, ethics, data availability), structured abstract
                            (Background and Aim / Methods / Results / Conclusions,
                            <=250 words), 3-5 MeSH keywords, Introduction / Methods /
                            Results / Discussion (<=3000 words, Conclusions inside the
                            Discussion), acknowledgments, Vancouver references with
                            superscript citation numbers, tables (titles above, no
                            vertical rules), and figure legends. 1.5 line spacing, US
                            spelling. Figures are supplied as separate files per JGH
                            guidelines.
01_manuscript_main_inline.docx For review only: same content with figures and tables
                            inline after their first citation (not for upload).
02_tables.docx              Tables 1-3 as a separate editable file
03_STROBE_checklist.docx    Completed STROBE checklist (Supplementary Material)
04_figures_editable.pptx    Figures 1-3, one per slide, editable (English)
figures/Figure1-3.png       High-resolution individual figure files (PNG) for upload
figures/Figure1-3.jpg       High-resolution individual figure files (JPG, 300 dpi)
figures/Figure1-3.tif       High-resolution individual figure files (TIFF, 300 dpi)

Every number, figure, and table is regenerated from the public NDB Open Data by the
pipeline in https://github.com/bougtoir/ndb-dea-drug-lag (download_ndb.py ->
build_dataset.py -> analyze.py -> course_estimate.py -> its_analysis.py ->
make_figures.py -> make_manuscript.py -> make_submission_zip.py --journal jgh).
Literature-derived numbers used in the Introduction/Discussion are kept in
data/discussion_support.json with their source keys.
