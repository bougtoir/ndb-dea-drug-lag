Hepatology International (APASL / Springer, hybrid) - submission package
================================================================================

Upload via Editorial Manager. Hybrid journal: the subscription route carries no
article-processing charge (the Open Choice open-access option is optional).

01_manuscript_main.docx     Main manuscript: title page (article type, authors/
                            affiliations, corresponding author, word counts,
                            table/figure counts, and the ethical-compliance
                            statements the journal asks for on the title page),
                            structured abstract (Background and Aims / Methods /
                            Results / Conclusions, <=250 words), Graphical
                            Abstract panel immediately after the abstract, 10
                            keywords, Introduction / Materials and Methods /
                            Results / Discussion (<=4,000 words including
                            references), Declarations (funding, conflict of
                            interest, ethics, consents, data and code
                            availability, authors' contributions), numbered NLM
                            references (<=30), tables (editable text), and
                            figure legends. Citations are numbered in square
                            brackets in order of first appearance.
01_manuscript_main_inline.docx For review only: same content with figures and
                            tables inline (not for upload).
02_cover_letter.docx        Cover letter (author details to be completed
                            locally)
03_tables.docx              Tables 1-3 as a separate editable file (also at the
                            end of the main manuscript)
04_STROBE_checklist.docx    Completed STROBE checklist (the journal asks for
                            STROBE with observational studies)
05_figures_source.pptx      Figures 1-3 source file, one per slide, editable
                            (English)
figures/Graphical_Abstract.tif  Mandatory single-panel graphical abstract
                            (300 dpi, Arial-metric font; also embedded in the
                            main document right after the abstract)
figures/Figure1-3.png       Individual figure files (PNG)
figures/Figure1-3.jpg       Individual figure files (JPG, 300 dpi)
figures/Figure1-3.tif       Individual figure files (TIFF, 300 dpi)

Every number, figure, and table is regenerated from the public NDB Open Data by
the pipeline in https://github.com/bougtoir/ndb-dea-drug-lag (download_ndb.py ->
build_dataset.py -> analyze.py -> course_estimate.py -> its_analysis.py ->
make_figures.py -> make_manuscript.py -> make_submission_zip.py --journal hi).
Literature-derived numbers used in the Introduction/Discussion are kept in
data/discussion_support.json with their source keys.
