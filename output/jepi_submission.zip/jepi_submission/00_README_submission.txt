Journal of Epidemiology (Japan Epidemiological Association) - submission package
================================================================================

Upload order per the Guide for Authors (ScholarOne): Highlights, main document,
tables/figures, supplementary files.

01_highlights.docx          Highlights (mandatory): 4 bullet points, each <=150
                            characters
02_manuscript_main.docx     Main manuscript: title page (article type, running
                            title <=8 words, authors/affiliations, corresponding
                            author, word counts, numbers of tables/figures/
                            supplementary materials), structured abstract
                            (Background/Methods/Results/Conclusions, <=250
                            words), 5 keywords, Introduction / Methods / Results /
                            Discussion (main text <=3,500 words, concluding
                            statement inside the Discussion), Acknowledgments
                            (funding, AI-use, and conflicts-of-interest
                            statements), Data Availability, AMA-style Vancouver
                            references with superscript citation numbers,
                            tables (editable text, no vertical rules), and
                            figure legends. Continuous line numbers run from
                            the Abstract through the Acknowledgments. Figures
                            are NOT embedded; they are supplied as separate
                            files per the Guide for Authors.
02_manuscript_main_inline.docx For review only: same content with figures and
                            tables inline (not for upload).
03_cover_letter.docx        Cover letter (journal name, title, principal
                            findings and their significance for epidemiology,
                            all-authors approval; author details to be
                            completed locally)
04_tables.docx              Tables 1-3 as a separate editable file (also at the
                            end of the main manuscript)
05_STROBE_checklist.docx    Completed STROBE checklist with a 'Reported on page
                            No.' column (supplementary file)
06_figures_source.pptx      Figures 1-3 source file, one per slide, editable
                            (English) - submitted as the figures' original
                            (source) files
figures/Figure1-3.png       Individual figure files (PNG)
figures/Figure1-3.jpg       Individual figure files (JPG, 300 dpi)
figures/Figure1-3.tif       Individual figure files (TIFF, 300 dpi)

Every number, figure, and table is regenerated from the public NDB Open Data by
the pipeline in https://github.com/bougtoir/ndb-dea-drug-lag (download_ndb.py ->
build_dataset.py -> analyze.py -> course_estimate.py -> its_analysis.py ->
make_figures.py -> make_manuscript.py -> make_submission_zip.py --journal jepi).
Literature-derived numbers used in the Introduction/Discussion are kept in
data/discussion_support.json with their source keys.
