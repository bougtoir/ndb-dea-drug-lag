Journal of Viral Hepatitis - submission package
=====================================

00_cover_letter.docx        Cover letter (word and reference counts, all-authors
                            approval; author details to be completed locally)
01_manuscript_main.docx     Main manuscript for submission: title page, keywords,
                            running title, authors/affiliations/ORCID, corresponding
                            author address, word counts, unstructured <=250-word
                            abstract, abbreviations list, IMRaD text, Statements and
                            Declarations, references, tables, and figure legends.
                            Figures are supplied as separate files per JVH guidelines.
01_manuscript_main_inline.docx For review only: same content with figures and tables
                            inline (not for submission in Editorial Manager).
02_tables.docx              Tables 1-3 as a separate editable file
03_STROBE_checklist.docx    Completed STROBE checklist (Supplementary Material)
04_figures_editable.pptx    Figures 1-3, one per slide, editable
figures/Figure1-3.png       High-resolution individual figure files (PNG) for upload
figures/Figure1-3.jpg       High-resolution individual figure files (JPG, 300 dpi)
figures/Figure1-3.tif       High-resolution individual figure files (TIFF, 300 dpi)

Every number, figure, and table is regenerated from the public NDB Open Data by the
pipeline in https://github.com/bougtoir/ndb-dea-drug-lag (download_ndb.py ->
build_dataset.py -> analyze.py -> course_estimate.py -> its_analysis.py ->
make_figures.py -> make_manuscript.py -> make_submission_zip.py).
