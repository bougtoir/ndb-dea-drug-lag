Emerging Infectious Diseases - submission package
=====================================

00_cover_letter.docx        Cover letter (article category, word and reference counts,
                            all-authors approval; author details to be completed locally)
01_manuscript_main.docx     Main manuscript: title page (article summary line, running
                            title, MeSH keywords, authors/affiliations/ORCID, corresponding
                            author address, word counts), unstructured 150-word abstract,
                            IMRaD text, acknowledgments, biographical sketch, address for
                            correspondence, references, tables (Word Table tool), and
                            figure legends. 12 pt Times New Roman, double-spaced, left
                            justified, continuous line numbering. Figures are NOT embedded
                            in the manuscript; they are supplied as separate files.
02_tables.docx              Tables 1-3 as a separate editable file
03_STROBE_checklist.docx    Completed STROBE checklist (Supplementary Material)
04_figures_editable.pptx    Figures 1-3, one per slide, editable
figures/Figure1-3.png       High-resolution individual figure files (PNG) for upload
figures/Figure1-3.jpg       High-resolution individual figure files (JPG, 300 dpi)

Every number, figure, and table is regenerated from the public NDB Open Data by the
pipeline in https://github.com/bougtoir/ndb-dea-drug-lag (download_ndb.py ->
build_dataset.py -> analyze.py -> course_estimate.py -> its_analysis.py ->
make_figures.py -> make_manuscript.py -> make_submission_zip.py).
