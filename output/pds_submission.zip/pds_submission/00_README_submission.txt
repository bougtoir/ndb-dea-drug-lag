Pharmacoepidemiology and Drug Safety - submission package
========================================================

00_cover_letter.docx        Cover letter (author details to be completed locally)
01_manuscript_main.docx     Main manuscript: title page, structured abstract, Key
                            Points, Plain Language Summary, IMRaD text with figures
                            and tables inline, Word-native equations, references
02_tables.docx              Tables 1-3 as separate editable files
03_STROBE_checklist.docx    Completed STROBE checklist (Supplementary Material)
04_figures_editable.pptx    Figures 1-3, one per slide, editable
figures/Figure1-3.png       Individual figure files for upload

Every number, figure, and table is regenerated from the public NDB Open Data by the
pipeline in https://github.com/bougtoir/ndb-dea-drug-lag (download_ndb.py ->
build_dataset.py -> analyze.py -> course_estimate.py -> its_analysis.py ->
make_figures.py -> make_manuscript.py -> make_submission_zip.py).
